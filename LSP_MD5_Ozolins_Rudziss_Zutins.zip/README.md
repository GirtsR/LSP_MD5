Building:

- `mkdir build`
- `cmake ..`
- `make`
